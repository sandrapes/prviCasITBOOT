package treca.nedelja.petak.domaci;

public class Fizikalac extends Radnik {


    public Fizikalac(String ime, double brojOdradjenihSati, double satnica) {
        super(ime, brojOdradjenihSati, satnica);
    }

}
